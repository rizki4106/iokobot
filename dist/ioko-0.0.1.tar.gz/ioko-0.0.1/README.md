# Ioko

Ioko is a python library to help you create learning system, for now ioko can be use for :

1. Chat Bot
2. Recommender System

# Installation

```bash
pip3 install ioko
```

or contribute to this project

```bash
git clone https://github.com/rizki4106/ioko.git && cd ioko
```

```bash
pip3 install -r requirements.txt
```

# Documentation

For more information please visit our wiki right here [https://github.com/rizki4106/ioko/wiki](https://github.com/rizki4106/ioko/wiki)
